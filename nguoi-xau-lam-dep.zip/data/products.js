const products = [
    {
        name: "Kem dưỡng da cao cấp",
        price: "500.000",
        image: "images/product1.jpg"
    },
    {
        name: "Son môi hồng tự nhiên",
        price: "350.000",
        image: "images/product2.jpg"
    },
    {
        name: "Sữa rửa mặt dịu nhẹ",
        price: "200.000",
        image: "images/product3.jpg"
    }
];
